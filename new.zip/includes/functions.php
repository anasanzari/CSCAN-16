<?php

// faculty : id,college,name,designation,interest,gender,food
// students: id,college,faculty,name,rollno,course,semester,gender,food


 ?>
