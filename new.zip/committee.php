<?php include_once './header.php'; ?>

  <nav class="navsection navbar navbar-default hidden-xs">
    <div class="container-fluid">
      <nav id="sac-navbar" class="navbar-collapse collapse">
            <ul class="nav navbar-nav">
              <li><a href="./">Home</a></li>
            </ul>

      </nav>
    </div>
  </nav>

  <div class="committe">
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-8 col-md-offset-2 col-xs-12">
          <h1>Committee</h1>

          <h2>Patron</h2>
            <p class="convenor"><span class="dir">Dr.Sivaji Chakravorti,</span><span> Director, NIT Calicut</span></p>

          <h2>Advisory Committee</h2>
            <p class="convenor"></p>
            <ul>
              <li>Dr. A. P. Shashikala,<span> Dean, Academic</span></li>
              <li>Dr. Abraham T. Mathew,<span> Dean, Research and Consultancy</span></li>
              <li>Dr. G Unnikrishnan,<span> Dean, Students Welfare</span></li>
              <li>Dr.R Sridharan,<span> Dean, Faculty Welfare</span></li>
              <li>Dr.S. Chandrakaran,<span> Dean, Planning & Development</span></li>
            </ul>




          <h2>Organizing Committe</h2>
          <h3>Convenor<h2>
            <p class="convenor">Dr S. D Madhukumar<br><span>Associate Professor and Former HOD, CSE Department.</span></p>
          <h3>Members</h3>
            <ul>
              <li>Dr K. A Abdul Nazeer,<span> Associate Professor and HOD, CSE Department.</span></li>
              <li>Ms Lijiya A</li>
              <li>Dr Gopakumar G</li>
              <li>Mr Ajayachandran V R</li>
              <li>K Prasad Krishnan</li>
              <li>Hemant Pugaliya</li>
              <li>Aishwarya Maruvada</li>
              <li>Vishnu Priya Matha</li>
              <li>Vivek Kumar</li>
              <li>Ojus Thomas Lee</li>
              <li>Denny Thomas</li>
              <li>Shishir Kumar</li>
              <li>Supriya Soni</li>
              <li>K Satya Kumar</li>
              <li>K Krishna Chaithanya</li>
              <li>Anas M</li>
            </ul>
        </div>
      </div>
    </div>
  </div>

  <div class="footer">
    <p> © Creative and Intellectual minds of NIT Calicut </p>
  </div>
